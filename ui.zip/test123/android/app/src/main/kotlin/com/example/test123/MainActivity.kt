package com.example.test123

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
